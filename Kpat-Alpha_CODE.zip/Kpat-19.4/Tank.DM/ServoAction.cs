﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kpat.Basic.DM;
using Kpat.DM;

namespace Tank.DM
{
    public class ServoAction : IAction
    {
        private ServoEngine servoEngine;
        private int turnDegrees;

        public ServoAction(int turnDegrees)
        {
            int pinNum = ConstsConfig.ServoPin.PinNumber;

            servoEngine = new ServoEngine(pinNum, turnDegrees);

            TurnDegrees = turnDegrees;
        }
        

        public int TurnDegrees
        {
            get { return turnDegrees; }
            set 
            {
                if (turnDegrees != value)
                {
                    turnDegrees = value;
                    servoEngine.TurnDegrees = turnDegrees;
                }
            }
        }

        public override void WriteActionToFile(StringBuilder sb)
        {
            base.WriteActionToFile(sb);

            servoEngine.WriteActionToFile(sb);
            sb.Append(Environment.NewLine);
        }

       
    }

}
