﻿using System.Runtime.Remoting.Messaging;
using Kpat.DM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tank.DM
{
    public static class ConstsConfig
    {
        public static int LeftEnginePinNum
        {
            get { return 1; }
        }

        public static int RightEnginePinNum
        {
            get { return 2; }
        }
        


        public static int TurnSpeed
        {
            get { return 5; }
        }

        public static int TurnTime
        {
            get { return 5; }
        }


        public static readonly PinDetails LedPin = new PinDetails()
        {
            PinNumber = 13,
            VarName = "ledPin",
            PinSetupString = @"pinMode(ledPin, OUTPUT)"
        };

        public static readonly PinDetails ServoPin = new PinDetails()
        {
            PinNumber = 9,
            VarName = "servoPin",
            PinSetupString = @"servoObject.attach(servoPin)"
        };


        public static readonly Dictionary<string, PinDetails> pinsConfig = new Dictionary<string, PinDetails>()
        {
            {LedPin.VarName,LedPin},
            {ServoPin.VarName, ServoPin},
        };
    }
}
