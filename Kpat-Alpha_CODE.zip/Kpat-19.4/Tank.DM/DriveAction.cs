﻿using Kpat.Basic.DM;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tank.DM
{
    public class DriveAction : IAction
    {
        private Engine leftEngine;
        private Engine rightEngine;
        private int speed;
        private Enums.Direction direction;
        private int time;

        public DriveAction(int speed, int time, Enums.Direction direction) 
        {
            int pinNumLeftEngine = ConstsConfig.LeftEnginePinNum;
            int pinNumRightEngine = ConstsConfig.RightEnginePinNum;

            leftEngine = new Engine(pinNumLeftEngine,speed,time,direction);
            rightEngine = new Engine(pinNumRightEngine, speed, time, direction);

            Speed = speed;
            Time = time;
            Direction = direction;
        }

        public int Speed
        {
            get { return speed; }
            set 
            {
                if (speed != value)
                {
                    speed = value;
                    leftEngine.Speed = speed;
                    rightEngine.Speed = speed;
                }
            }
        }

        public Enums.Direction Direction
        {
            get { return direction; }
            set 
            {
                if (direction != value)
                {
                    direction = value;
                    leftEngine.Direction = direction;
                    rightEngine.Direction = direction;
                }
            }
        }

        public int Time
        {
            get { return time; }
            set
            {
                if (time != value)
                {
                    time = value;
                    leftEngine.Time = time;
                    rightEngine.Time = time;
                }
            }
        }

        public override void WriteActionToFile(StringBuilder sb)
        {
            base.WriteActionToFile(sb);

            leftEngine.WriteActionToFile(sb);
            rightEngine.WriteActionToFile(sb);
            sb.Append(Environment.NewLine); 
        }
    }
}
