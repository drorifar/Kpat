﻿using Kpat.Basic.DM;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tank.DM
{
    public class TurnAction : IAction
    {
        private Engine turnEngine;
        private Enums.TurnDirection turnDirection;

        //consts
        private int pinNumLeftEngine = ConstsConfig.LeftEnginePinNum;
        private int pinNumRightEngine = ConstsConfig.RightEnginePinNum;
        private int turnSpeed = ConstsConfig.TurnSpeed;
        private int turnTime = ConstsConfig.TurnTime;

        public TurnAction(Enums.TurnDirection turnDirection)
        {
            if (turnDirection == Enums.TurnDirection.left)
            {
                turnEngine = new Engine(pinNumRightEngine, turnSpeed, turnTime, Enums.Direction.forward);
            }
            else turnEngine = new Engine(pinNumLeftEngine, turnSpeed, turnTime, Enums.Direction.forward);           
        }        

        public Enums.TurnDirection TurnDirection
        {
            get { return turnDirection; }
            set
            {
                if (turnDirection != value)
                {
                    turnDirection = value;
                    //if the direction is left the right engine drive and vice versa
                    turnEngine.PinNum = turnDirection == Enums.TurnDirection.left ? pinNumRightEngine : pinNumLeftEngine;
                }
            }
        }

        

        public override void WriteActionToFile(StringBuilder sb)
        {
            base.WriteActionToFile(sb);

            turnEngine.WriteActionToFile(sb);
            sb.Append(Environment.NewLine); 
        }
    }
}
