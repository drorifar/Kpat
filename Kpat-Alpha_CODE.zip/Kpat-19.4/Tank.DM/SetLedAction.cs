﻿using Kpat.Basic.DM;
using Kpat.DM;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tank.DM
{
    public class SetLedAction : IAction
    {
        private Led led; 
        private int intensity;
        private int time;

        
        public SetLedAction(int intensity, int time) 
        {
            int pinNum = ConstsConfig.LedPin.PinNumber;

            led = new Led(pinNum, intensity, time);

            Intensity = intensity;
            Time = time;
        }

        public int Intensity
        {
            get { return intensity; }
            set 
            {
                if (intensity != value)
                {
                    intensity = value;
                    led.Intensity = intensity;
                }
            }
        }

       
        public int Time
        {
            get { return time; }
            set
            {
                if (time != value)
                {
                    time = value;
                    led.Time = time;
                }
            }
        }

        public override void WriteActionToFile(StringBuilder sb)
        {
            base.WriteActionToFile(sb);

            led.WriteActionToFile(sb);
            sb.Append(Environment.NewLine); 
        }
    }
}
