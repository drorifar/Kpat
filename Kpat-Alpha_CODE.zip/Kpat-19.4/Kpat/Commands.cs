﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Kpat.UI
{
    public static class Commands
    {
         private static RoutedCommand DelActionCommand;

         public static RoutedCommand DelAction
         {
             get { return DelActionCommand; }
         }

         static Commands()
         {
             DelActionCommand = new RoutedCommand("DelAction", typeof(Commands));
         }
    }
}
