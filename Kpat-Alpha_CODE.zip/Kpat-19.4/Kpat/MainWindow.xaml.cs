﻿using Kpat.Basic.DM;
using Kpat.DM;
using Kpat.UI.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Tank.DM;

namespace Kpat.UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //  public List<IAction> actionList;

        public MainWindow()
        {
            InitializeComponent();

            actionsList = new List<IAction>();
            actionsString = new StringBuilder();
            ClearActions();
            //     MockUp();
            AddEventsHandler();
        }

        private void AddEventsHandler()
        {
            //add the delete child action event handler (set it to the DeleteChildEventHandler function)
            this.AddHandler(ActionControlBase.DeleteChildEvent, new RoutedEventHandler(DeleteChildEventHandler));
        }

        public List<IAction> actionsList;
        private StringBuilder actionsString;

        private void WriteActionsToString()
        {
            foreach (var item in actionsList)
            {
                item.WriteActionToFile(actionsString);
            }

            //  this.fileTxtBox.Text = actionsString.ToString();
        }

        private void MockUp()
        {
            DriveAction moveForward = new DriveAction(20, 1, Enums.Direction.forward);
            TurnAction turnRight = new TurnAction(Enums.TurnDirection.right);
            TurnAction turnLeft = new TurnAction(Enums.TurnDirection.left);

            actionsList.Add(moveForward);
            actionsList.Add(turnRight);

            turnLeft.TurnDirection = Enums.TurnDirection.right;
            moveForward.Speed = 6;

            LoopAction loop = new LoopAction(5, 0);
            loop.Add(new DriveAction(20, 1, Enums.Direction.forward));
            loop.Add(new TurnAction(Enums.TurnDirection.right));
            actionsList.Add(loop);

            actionsList.Add(moveForward);
            actionsList.Add(turnLeft);

            WriteActionsToString();
        }

        private void GetFile_Click(object sender, RoutedEventArgs e)
        {
            ClearActions();

            var actions = actionListPanel.Children;

            AddActionsToList(actions, this.actionsList, 0);

            WriteActionsToString();

            string completeFile = FileSkelaton.CreateArduinoFile(ConstsConfig.pinsConfig, actionsString.ToString());

            this.fileTxtBox.Text = completeFile;
        }

        private void AddActionsToList(UIElementCollection actionsUC, List<IAction> list, int innerLoopIndex)
        {
            foreach (var actionUC in actionsUC)
            {
                if (actionUC is DriveActionUC)
                {
                    DriveActionUC driveAction = actionUC as DriveActionUC;
                    list.Add(new DriveAction(driveAction.Speed, driveAction.Time, driveAction.Direction));
                }
                else if (actionUC is TurnActionUC)
                {
                    TurnActionUC turnAction = actionUC as TurnActionUC;
                    list.Add(new TurnAction(turnAction.TurnDirection));
                }
                else if (actionUC is LedActionUC)
                {
                    LedActionUC ledAction = actionUC as LedActionUC;
                    //set the intensity between 0-255
                    int normalizeIntensity = Utilities.Arduino255Normalize(ledAction.Intensity, UIConst.MaxClientLed);
                    list.Add(new SetLedAction(normalizeIntensity, ledAction.Time));
                }
                else if (actionUC is ServoActionUC)
                {
                    ServoActionUC servoAction = actionUC as ServoActionUC;
                    int normalizeDegrees = Utilities.Arduino255Normalize(servoAction.TurnDegrees, UIConst.MaxClientServo);
                    list.Add(new ServoAction(normalizeDegrees));
                }
                else if (actionUC is LoopActionUC)
                {
                    LoopActionUC loopActionUC = actionUC as LoopActionUC;
                    LoopAction loop = new LoopAction(loopActionUC.LoopAmount, innerLoopIndex++);
                    AddActionsToList(loopActionUC.ActionsUcList, loop.LoopActions, innerLoopIndex);
                    list.Add(loop);
                }
            }
        }

        private void ClearActions()
        {
            actionsList.Clear();
            this.fileTxtBox.Text = "";
            actionsString.Clear();
            actionsString.Append(Environment.NewLine);
        }

        #region events handlers
        private void DeleteChildEventHandler(object sender, RoutedEventArgs e)
        {
            // Code to handle the event raised from the child
            if (e.Source is ActionControlBase)
            {
                ActionControlBase deletedAction = e.Source as ActionControlBase;
                actionListPanel.Children.Remove(deletedAction);
                e.Handled = true;
            }
        }
        #endregion

        #region controls Commands
        private void AddDrive_Click(object sender, RoutedEventArgs e)
        {
            this.actionListPanel.Children.Add(new DriveActionUC()
            {
                // HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                Margin = new Thickness(5)
            });
        }

        private void AddTurn_Click(object sender, RoutedEventArgs e)
        {
            this.actionListPanel.Children.Add(new TurnActionUC()
            {
                //  HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                Margin = new Thickness(5)
            });
        }

        private void AddLed_Click(object sender, RoutedEventArgs e)
        {
            this.actionListPanel.Children.Add(new LedActionUC()
            {
                //  HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                Margin = new Thickness(5)
            });
        }

        private void AddServo_Click(object sender, RoutedEventArgs e)
        {
            this.actionListPanel.Children.Add(new ServoActionUC()
            {
                //  HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                Margin = new Thickness(5)
            });
        }

        private void AddLoop_Click(object sender, RoutedEventArgs e)
        {
            this.actionListPanel.Children.Add(new LoopActionUC()
            {
                //  HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                Margin = new Thickness(5)
            });
        }

        private void DeleteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void DeleteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            UserControl deletedAction = e.Source as UserControl;
            actionListPanel.Children.Remove(deletedAction);
        }
        #endregion
    }
}
