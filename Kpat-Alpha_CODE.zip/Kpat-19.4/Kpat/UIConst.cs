﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Kpat.UI
{
    public class UIConst
    {
        public static readonly List<Brush> InnerLoopsBrushes = new List<Brush>
        {
            Brushes.BurlyWood,
            Brushes.Red,
            Brushes.Blue,
            Brushes.Yellow,
            Brushes.Green
        };
        
        public static int MaxClientLed
        {
            get { return 5; }
        }

        public static int MaxClientServo
        {
            get { return 180; }
        }
    }
}
