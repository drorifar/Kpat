﻿using Kpat.Basic.DM;
using Kpat.UI.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kpat.UI
{
    /// <summary>
    /// Interaction logic for DriveActionUC.xaml
    /// </summary>
    public partial class DriveActionUC : ActionControlBase
    {
        public DriveActionUC()
        {
            InitializeComponent();
            this.DataContext = this;
            InitCombo();
        }


        private void InitCombo()
        {
            this.directionCB.ItemsSource = new List<Enums.Direction>()
            {
                Enums.Direction.forward,
                Enums.Direction.backward
            };
            this.directionCB.SelectedIndex = 0;

            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5, 6, 7 };

            this.speedCB.ItemsSource = numbers;
            this.timeCB.ItemsSource = numbers;

            this.speedCB.SelectedItem = numbers[2];
            this.timeCB.SelectedItem = numbers[2];

            this.Speed = Int32.Parse(this.speedCB.SelectedValue.ToString());
            this.Time = Int32.Parse(this.timeCB.SelectedItem.ToString());

            this.Direction = this.directionCB.SelectedValue.ToString() == Enums.Direction.forward.ToString() ? Enums.Direction.forward : Enums.Direction.backward;
       

        }

        #region DependencyProperties
        public Enums.Direction Direction
        {
            get { return (Enums.Direction)GetValue(DirectionProperty); }
            set { SetValue(DirectionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Direction.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DirectionProperty =
            DependencyProperty.Register("Direction", typeof(Enums.Direction), typeof(DriveActionUC), new PropertyMetadata(Enums.Direction.forward));
        
        public int Speed
        {
            get { return (int)GetValue(SpeedProperty); }
            set { SetValue(SpeedProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Speed.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SpeedProperty =
            DependencyProperty.Register("Speed", typeof(int), typeof(DriveActionUC), new PropertyMetadata(0));

        public int Time
        {
            get { return (int)GetValue(TimeProperty); }
            set { SetValue(TimeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Time.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TimeProperty =
            DependencyProperty.Register("Time", typeof(int), typeof(DriveActionUC), new PropertyMetadata(0));

        #endregion

    }
}
