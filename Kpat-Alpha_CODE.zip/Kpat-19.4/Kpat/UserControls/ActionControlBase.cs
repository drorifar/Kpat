﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Kpat.UI.UserControls
{
    public class ActionControlBase : UserControl
    {
        // This defines the custom event
        public static readonly RoutedEvent DeleteChildEvent = EventManager.RegisterRoutedEvent(
            "DeleteChild", // Event name
            RoutingStrategy.Bubble, // Bubble means the event will bubble up through the tree
            typeof(RoutedEventHandler), // The event type
            typeof(ActionControlBase)); // Belongs to ChildControlBase
        // Allows add and remove of event handlers to handle the custom event
        public event RoutedEventHandler DeleteChild
        {
            add { AddHandler(DeleteChildEvent, value); }
            remove { RemoveHandler(DeleteChildEvent, value); }
        }

        protected void Delete_Click(object sender, RoutedEventArgs e)
        {
            // This actually raises the custom event
            var newEventArgs = new RoutedEventArgs(DeleteChildEvent);
            RaiseEvent(newEventArgs);
        }
    }
}
