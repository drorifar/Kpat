﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kpat.UI.UserControls
{
    /// <summary>
    /// Interaction logic for LedActionUC.xaml
    /// </summary>
    public partial class LedActionUC : ActionControlBase
    {
        public LedActionUC()
        {
            InitializeComponent();
            this.DataContext = this;
            InitCombo();
        }


        private void InitCombo()
        {           
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5, 6, 7 };

            List<int> intensityComboList = new List<int>();
            
            for (int i = 1; i <= UIConst.MaxClientLed; i++)
            {
                intensityComboList.Add(i);
            }

            this.intensityCB.ItemsSource = intensityComboList;
            this.timeCB.ItemsSource = numbers;

            this.intensityCB.SelectedItem = intensityComboList[2];
            this.timeCB.SelectedItem = numbers[2];

            this.Intensity = Int32.Parse(this.intensityCB.SelectedValue.ToString());
            this.Time = Int32.Parse(this.timeCB.SelectedItem.ToString());            

        }

        #region DependencyProperties

        public int Intensity
        {
            get { return (int)GetValue(IntensityProperty); }
            set { SetValue(IntensityProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Speed.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IntensityProperty =
            DependencyProperty.Register("Intensity", typeof(int), typeof(LedActionUC), new PropertyMetadata(0));

        public int Time
        {
            get { return (int)GetValue(TimeProperty); }
            set { SetValue(TimeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Time.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TimeProperty =
            DependencyProperty.Register("Time", typeof(int), typeof(LedActionUC), new PropertyMetadata(0));

        #endregion
    }
}
