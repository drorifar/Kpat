﻿using Kpat.Basic.DM;
using Kpat.UI.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kpat.UI
{
    /// <summary>
    /// Interaction logic for DriveActionUC.xaml
    /// </summary>
    public partial class TurnActionUC : ActionControlBase
    {
        public TurnActionUC()
        {
            InitializeComponent();
            this.DataContext = this;
            InitCombo();
        }

        private void InitCombo()
        {
            this.directionCB.ItemsSource = new List<Enums.TurnDirection>()
            {
                Enums.TurnDirection.left,
                Enums.TurnDirection.right
            };
            this.directionCB.SelectedIndex = 0;              

        }

        public Enums.TurnDirection TurnDirection
        {
            get { return (Enums.TurnDirection)GetValue(TurnDirectionProperty); }
            set { SetValue(TurnDirectionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Direction.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TurnDirectionProperty =
            DependencyProperty.Register("TurnDirection", typeof(Enums.TurnDirection), typeof(DriveActionUC), new PropertyMetadata(Enums.TurnDirection.left));

    }
}
