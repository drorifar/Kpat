﻿using Kpat.Basic.DM;
using Kpat.UI.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kpat.UI
{
    /// <summary>
    /// Interaction logic for DriveActionUC.xaml
    /// </summary>
    public partial class LoopActionUC : ActionControlBase
    {
        private int innerLoopsBrushesIndex = 0;

        public LoopActionUC()
        {
            InitializeComponent();
            this.DataContext = this;
            InitCombo();

            AddEventsHandler();           
        }

        private void AddEventsHandler()
        {
            //add the delete child action event handler (set it to the DeleteChildEventHandler function)
            this.AddHandler(ActionControlBase.DeleteChildEvent, new RoutedEventHandler(DeleteChildEventHandler));
        }

        private void InitCombo()
        {
            this.amountCB.ItemsSource = new List<int>() { 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            this.amountCB.SelectedIndex = 0;

            this.LoopAmount = Int32.Parse(this.amountCB.SelectedValue.ToString());
        }

        public int LoopAmount
        {
            get { return (int)GetValue(LoopAmountProperty); }
            set { SetValue(LoopAmountProperty, value); }
        }

        // Using a DependencyProperty as the backing store for LoopAmount.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LoopAmountProperty =
            DependencyProperty.Register("LoopAmount", typeof(int), typeof(LoopActionUC), new PropertyMetadata(0));



        public Brush LoopBackGround
        {
            get { return (Brush)GetValue(LoopBackGroundProperty); }
            set { SetValue(LoopBackGroundProperty, value); }
        }

        // Using a DependencyProperty as the backing store for LoopBackGround.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LoopBackGroundProperty =
            DependencyProperty.Register("LoopBackGround", typeof(Brush), typeof(LoopActionUC), new PropertyMetadata(Brushes.BurlyWood));



        public UIElementCollection ActionsUcList
        {
            get
            {
                return this.loopListPanel.Children;
            }
        }

        #region events handled
        private void DeleteChildEventHandler(object sender, RoutedEventArgs e)
        {
            // Code to handle the event raised from the child
            if (e.OriginalSource is ActionControlBase)
            {
                ActionControlBase deletedAction = e.OriginalSource as ActionControlBase;
                if (loopListPanel.Children.Contains(deletedAction)) //checks if the action is this loop child
                {
                    loopListPanel.Children.Remove(deletedAction);//if so remove it from the list
                    e.Handled = true;  // stop the event bubbling further if you need to
                }
                else e.Handled = false;//else keep bubbling it to the next loop/main window
            }
        }
        #endregion

        #region controls Commands
        private void AddDrive_Click(object sender, RoutedEventArgs e)
        {
            this.loopListPanel.Children.Add(new DriveActionUC()
            {
                // HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                Margin = new Thickness(5)
            });
        }

        private void AddTurn_Click(object sender, RoutedEventArgs e)
        {
            this.loopListPanel.Children.Add(new TurnActionUC()
            {
                //  HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                Margin = new Thickness(5)
            });
        }

        private void AddLed_Click(object sender, RoutedEventArgs e)
        {
            this.loopListPanel.Children.Add(new LedActionUC()
            {
                //  HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                Margin = new Thickness(5)
            });
        }

        private void AddServo_Click(object sender, RoutedEventArgs e)
        {
            this.loopListPanel.Children.Add(new ServoActionUC()
            {
                //  HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                Margin = new Thickness(5)
            });
        }
        
        private void AddLoop_Click(object sender, RoutedEventArgs e)
        {
            int newLoopBrushIndex = 0;
            if (this.innerLoopsBrushesIndex < UIConst.InnerLoopsBrushes.Count - 1) // check if its the end off the colors, if so start from the begining
            {
                newLoopBrushIndex = this.innerLoopsBrushesIndex + 1;
            }
            this.loopListPanel.Children.Add(new LoopActionUC()
            {
                //  HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                Margin = new Thickness(5),
                LoopBackGround = UIConst.InnerLoopsBrushes[newLoopBrushIndex],
                innerLoopsBrushesIndex = newLoopBrushIndex//set the backroundColor of the next inner loop
            });
        }


        private void DeleteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void DeleteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            UserControl deletedAction = e.Source as UserControl;
            loopListPanel.Children.Remove(deletedAction);
        }
        #endregion

        
    }
}
