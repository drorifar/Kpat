﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kpat.UI.UserControls
{
    /// <summary>
    /// Interaction logic for ServoActionUC.xaml
    /// </summary>
    public partial class ServoActionUC : ActionControlBase
    {
        public ServoActionUC()
        {
            InitializeComponent();
            this.DataContext = this;
            InitCombo();
        }

        private void InitCombo()
        {
            //  List<int> numbers = new List<int>() { 0, 30, 45, 60, 90, 120, 180 };

            List<int> degreesComboList = new List<int>() { 0, 30, 45, 60, 90, 120, 180 };
/*
            for (int i = 0; i <= UIConst.MaxClientServo; i++)
            {
                degreesComboList.Add(i);
            }
*/
            this.TurnDegreesCB.ItemsSource = degreesComboList;

            this.TurnDegreesCB.SelectedItem = degreesComboList[2];

            this.TurnDegrees = Int32.Parse(this.TurnDegreesCB.SelectedValue.ToString());
        }

        #region DependencyProperties

        public int TurnDegrees
        {
            get { return (int)GetValue(TurnDegreesProperty); }
            set { SetValue(TurnDegreesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Speed.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TurnDegreesProperty =
            DependencyProperty.Register("TurnDegrees", typeof(int), typeof(ServoActionUC), new PropertyMetadata(0));
        
        #endregion

        
    }
}
