﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kpat.UI
{
    //temp class for checking the iotput file
    class MockUp
    {
        void temp()
        {
            /*Start File*/

            /*LoopAction*/
            for (int i0 = 0; i0 < 2; i0++)
            {
                /*LoopAction*/
                for (int i1 = 0; i1 < 2; i1++)
                {
                    /*LoopAction*/
                    for (int i2 = 0; i2 < 2; i2++)
                    {
                        /*LoopAction*/
                        for (int i3 = 0; i3 < 2; i3++)
                        {
                            /*TurnAction*/
                            MoveEngine(2, forward, 5, 5);

                        }
                        /*TurnAction*/
                        MoveEngine(2, forward, 5, 5);

                    }
                    /*TurnAction*/
                    MoveEngine(2, forward, 5, 5);

                }
                /*TurnAction*/
                MoveEngine(2, backward, 5, 5);

            }
            /*End File*/
        }

        private int forward = 1;
        private int backward = 2;
        private void MoveEngine(int i, int j, int k, int l)
        {
        }
    }
}
