﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kpat.Basic.DM
{
    public class Enums
    {
        public enum Direction { forward, backward };

        public enum TurnDirection { left, right };
    }
}
