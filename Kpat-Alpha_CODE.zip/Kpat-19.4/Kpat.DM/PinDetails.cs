﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kpat.DM
{
    public class PinDetails
    {
        private int pinNumber;

        public int PinNumber
        {
            get { return pinNumber; }
            set { pinNumber = value; }
        }

        //the line that we need to write in the setup function in the arduino program for that Element
        private string pinSetupString;

        public string PinSetupString
        {
            get { return pinSetupString; }
            set { pinSetupString = value; }
        }

        private string varName;

        public string VarName
        {
            get { return varName; }
            set { varName = value; }
        }
        
        
    }
}
