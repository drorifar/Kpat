﻿using Kpat.DM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kpat.DM
{
    public class FileSkelaton
    {
        public static string CreateArduinoFile(Dictionary<string, PinDetails> pinsConfig, string clientLoopString)
        {
            StringBuilder file = new StringBuilder();
            file.Append(@"/*Start File*/");
            file.Append(Environment.NewLine);
            file.Append(Environment.NewLine);

            file.Append(AddIncludes());
            file.Append(AddFunctions());

            #region set pins consts
            
            file.Append(Environment.NewLine);

            foreach (var pin in pinsConfig)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("int ");
                sb.Append(pin.Key + " = ");
                sb.Append(pin.Value.PinNumber.ToString());
                sb.Append(";");

                file.Append(sb.ToString());
                file.Append(Environment.NewLine);
            }
            #endregion

            file.Append(Environment.NewLine);

            #region setup string
            file.Append(@"void setup() {");
            file.Append(Environment.NewLine);

            foreach (var pin in pinsConfig)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(pin.Value.PinSetupString);
                sb.Append(";");

                file.Append(sb.ToString());
                file.Append(Environment.NewLine);
            }

            file.Append(@"}");
            file.Append(Environment.NewLine);
            #endregion

            file.Append(Environment.NewLine);

            #region loop string

            file.Append(@"void loop() {");
            file.Append(Environment.NewLine);
            file.Append(clientLoopString);
            file.Append(@"while(1) { }");
            file.Append(Environment.NewLine);
            file.Append(@"}");
            file.Append(Environment.NewLine);

            #endregion

            file.Append(Environment.NewLine);
            file.Append(@"/*End File*/");
            return file.ToString();
        }

        private static string AddIncludes()
        {
            StringBuilder sb = new StringBuilder();

            string ServoInclude =
                @"#include <Servo.h>";

            sb.Append(ServoInclude);
            sb.Append(Environment.NewLine);
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }

        private static string AddFunctions()
        {
            StringBuilder sb = new StringBuilder();

            string LedFunction =
                @"void SetLed (int aux, int intensity, int time){
    digitalWrite(aux, HIGH); 
    delay(time * 1000);
    digitalWrite(aux, LOW);
    delay(1000);
}";

            string ServoFunction =
        @"void MoveServoEngine (int aux, int degree){
    Servo servoObject;
    servoObject.attach(aux);
    servoObject.write (degree);	
}";
            sb.Append(LedFunction);
            sb.Append(Environment.NewLine);
            sb.Append(Environment.NewLine);
            sb.Append(ServoFunction);
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }
    }
}
