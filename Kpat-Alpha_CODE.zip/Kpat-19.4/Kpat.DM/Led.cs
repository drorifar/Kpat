﻿using Kpat.Basic.DM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kpat.DM
{
    public class Led :IAction
    {
        private int pinNum;
        private int intensity;
        private int time;

        public Led(int pinNum, int intensity, int time) 
        {
            PinNum = pinNum;
            Intensity = intensity;
            Time = time;
        }

        public int PinNum
        {
            get { return pinNum; }
            set { pinNum = value; }
        }

        public int Intensity
        {
            get { return intensity; }
            set { intensity = value; }
        }

        public int Time
        {
            get { return time; }
            set { time = value; }
        }        

        public override void WriteActionToFile(StringBuilder sb)
        {
            string ledString = String.Format(@"SetLed ({0}, {1}, {2});", PinNum, Intensity, Time);
            sb.Append(ledString);
            sb.Append(Environment.NewLine);           
        }
    }
}