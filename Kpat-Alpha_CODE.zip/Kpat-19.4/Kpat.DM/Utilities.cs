﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kpat.DM
{
    public class Utilities
    {
        //get a number from the client and return the normalize number between 0-255 for arduino
        public static int Arduino255Normalize(int clientNum, int maxClientNum)
        {
            int returnValue = 0;

            returnValue = 255 / maxClientNum * clientNum;
            return returnValue;
        }
    }
}
