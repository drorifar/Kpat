﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kpat.Basic.DM
{
    public abstract class IAction
    {
        public virtual void WriteActionToFile(StringBuilder sb)
        {
            sb.Append(@"/*" + this.GetType().Name + @"*/");
            sb.Append(Environment.NewLine); 
        }
    }
}
