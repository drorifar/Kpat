﻿using Kpat.Basic.DM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kpat.DM
{
    public class LoopAction : IAction
    {
        private List<IAction> loopActions;
        private int numOfIterations;
        private int loopIndex; //verb for describe the inner loop index for the loop verb (i0, i1...);

        public LoopAction(int numOfIterations, int loopIndex)
        {
            loopActions = new List<IAction>();
            this.numOfIterations = numOfIterations;
            this.loopIndex = loopIndex;
        }

        public List<IAction> LoopActions
        {
            get { return loopActions; }
            set { loopActions = value; }
        }

        public int NumOfIterations
        {
            get { return numOfIterations; }
            set { numOfIterations = value; }
        }


        public override void WriteActionToFile(StringBuilder sb)
        {
            if (loopActions != null && loopActions.Count > 0 && numOfIterations > 0)
            {
                base.WriteActionToFile(sb);

                AddForLoopString(sb, true); //add the start of the loop string

                foreach (var action in loopActions)
                {
                    action.WriteActionToFile(sb);
                }

                AddForLoopString(sb, false); // add the end of the loop string

            }
        }

        private void AddForLoopString(StringBuilder sb, bool isStart)
        {
            if (isStart)
            {
                string forString = String.Format(@"for (int i{1}=0; i{1}<{0}; i{1}++)", numOfIterations, loopIndex);
                sb.Append(forString);
                sb.Append(Environment.NewLine);
                sb.Append(@"{");
                sb.Append(Environment.NewLine);
            }
            else
            {
                sb.Append(@"}");
                sb.Append(Environment.NewLine);
            }

        }

        #region list methods
        public void Add(IAction action)
        {
            if (loopActions != null)
            {
                loopActions.Add(action);
            }
        }

        public void Remove(IAction action)
        {
            if (loopActions != null)
            {
                loopActions.Remove(action);
            }
        }

        public void AddRange(List<IAction> actions)
        {
            if (loopActions != null)
            {
                loopActions.AddRange(actions);
            }
        }
        #endregion

    }
}