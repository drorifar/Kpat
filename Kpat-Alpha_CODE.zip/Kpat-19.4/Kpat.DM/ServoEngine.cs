﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kpat.Basic.DM;

namespace Kpat.DM
{
    public class ServoEngine : IAction
    {
        private int pinNum;
        private int turnDegrees;

        //Constarctor
        public ServoEngine(int pinNum, int turnDegrees)
        {
            PinNum = pinNum;
            TurnDegrees = turnDegrees;
        }

        public int PinNum
        {
            get { return pinNum; }
            set { pinNum = value; }
        }

        public int TurnDegrees
        {
            get { return turnDegrees; }
            set { turnDegrees = value; }
        }

        public override void WriteActionToFile(StringBuilder sb)
        {
            string servoEngineString = String.Format(@"SetServoEngine ({0}, {1});", PinNum, TurnDegrees);
            sb.Append(servoEngineString);
            sb.Append(Environment.NewLine);
        }
    }
}
