﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kpat.Basic.DM
{
    public class Engine : IAction
    {
        private int pinNum;
        private int speed;
        private Enums.Direction direction;
        private int time;

        public Engine(int pinNum, int speed, int time, Enums.Direction direction) 
        {
            PinNum = pinNum;
            Speed = speed;
            Time = time;
            Direction = direction;
        }

        public int PinNum
        {
            get { return pinNum; }
            set { pinNum = value; }
        }        

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public Enums.Direction Direction
        {
            get { return direction; }
            set { direction = value; }
        }

        public int Time
        {
            get { return time; }
            set { time = value; }
        }        

        public override void WriteActionToFile(StringBuilder sb)
        {
            string moveString = String.Format(@"MoveEngine ({0}, {1}, {2} , {3});", PinNum, Direction, Speed, Time);
            sb.Append(moveString);
            sb.Append(Environment.NewLine);           
        }
    }
}
